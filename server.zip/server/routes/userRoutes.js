import express from 'express';
import { getUserProfile } from '../controllers/userController.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import multer from 'multer';

const router = express.Router();
const upload = multer({ dest: 'uploads/' });
// Route for profile picture upload
router.post('/api/users/profile/picture', upload.single('profilePicture'), async (req, res) => {
    try {
        // Handle the uploaded file and update the user's profile picture
        const userId = req.session.currentUser.userId;
        const filePath = req.file.path;

        // Update the user's profile picture in the database
        await User.findByIdAndUpdate(userId, { profilePicture: filePath });

        res.status(200).json({ message: 'Profile picture uploaded successfully' });
    } catch (error) {
        console.error('Error uploading profile picture:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

router.get('/profile', authMiddleware, getUserProfile);
export default router;