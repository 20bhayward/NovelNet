import React, { useState } from 'react';
import { Form, Button } from 'react-bootstrap';

interface SearchSidebarProps {
  onSearch: (query: string) => void;
  onSort: (option: string) => void;
  onFilters: (filters: any) => void;
  sortOption: string;
  filters: any;
}

const SearchSidebar: React.FC<SearchSidebarProps> = ({
  onSearch,
  onSort,
  onFilters,
  sortOption,
  filters,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [minRating, setMinRating] = useState<number | null>(null);
  const [statuses, setStatuses] = useState<string[]>([]);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleSearchSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSearch(searchTerm);
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onSort(e.target.value);
  };

  const handleTagsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const tag = e.target.value;
    if (e.target.checked) {
      setTags([...tags, tag]);
    } else {
      setTags(tags.filter((t) => t !== tag));
    }
    onFilters({ ...filters, tags });
  };

  const handleMinRatingChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value ? parseInt(e.target.value, 10) : null;
    setMinRating(value);
    onFilters({ ...filters, minRating: value });
  };

  const handleStatusChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const status = e.target.value;
    if (e.target.checked) {
      setStatuses([...statuses, status]);
    } else {
      setStatuses(statuses.filter((s) => s !== status));
    }
    onFilters({ ...filters, status: statuses });
  };

  return (
    <div className="sidebar">
      <Form onSubmit={handleSearchSubmit}>
        <Form.Group controlId="searchInput">
          <Form.Label>Search</Form.Label>
          <Form.Control
            type="text"
            value={searchTerm}
            onChange={handleSearchChange}
            placeholder="Enter search term"
          />
        </Form.Group>
        <Button variant="primary" type="submit">
          Search
        </Button>
      </Form>

      <Form.Group controlId="sortOptions">
        <Form.Label>Sort By</Form.Label>
        <Form.Control as="select" value={sortOption} onChange={handleSortChange}>
          <option value="relevance">Relevance</option>
          <option value="alphabetical">Alphabetical</option>
          <option value="rating">Rating</option>
          <option value="popularity">Popularity</option>
        </Form.Control>
      </Form.Group>

      <Form.Group controlId="tagsFilter">
        <Form.Label>Tags</Form.Label>
        {/* Add checkboxes for tags here */}
        <Form.Check
          type="checkbox"
          label="Tag 1"
          value="tag1"
          checked={tags.includes('tag1')}
          onChange={handleTagsChange}
        />
        {/* Add more checkboxes as needed */}
      </Form.Group>

      <Form.Group controlId="ratingFilter">
        <Form.Label>Minimum Rating</Form.Label>
        <Form.Control
          type="number"
          value={minRating || ''}
          onChange={handleMinRatingChange}
          min={0}
          max={100}
        />
      </Form.Group>

      <Form.Group controlId="statusFilter">
        <Form.Label>Status</Form.Label>
        {/* Add checkboxes for status here */}
        <Form.Check
          type="checkbox"
          label="Ongoing"
          value="ongoing"
          checked={statuses.includes('ongoing')}
          onChange={handleStatusChange}
        />
        <Form.Check
          type="checkbox"
          label="Completed"
          value="completed"
          checked={statuses.includes('completed')}
          onChange={handleStatusChange}
        />
        {/* Add more checkboxes as needed */}
      </Form.Group>
    </div>
  );
};

export default SearchSidebar;