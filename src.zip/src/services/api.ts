import axios from 'axios';

const apiBaseURL = 'http://localhost:5000'; // Update the base URL to match the server's URL

export default axios.create({
  baseURL: apiBaseURL,
  withCredentials: true, // Enable sending cookies with requests
});