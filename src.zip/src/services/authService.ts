import api from './api';

const registerUser = async (username: string, password: string, role: string) => {
  try {
    await api.post('/api/auth/register', { username, password, role });
  } catch (error) {
    throw error;
  }
};

const loginUser = async (username: string, password: string) => {
  try {
    const response = await api.post('/api/auth/login', { username, password });
    return response.data;
  } catch (error) {
    throw error;
  }
};

const logout = () => {
  localStorage.removeItem('token');
};

export { registerUser, loginUser, logout };