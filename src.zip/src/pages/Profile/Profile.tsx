import React, { useEffect, useState, useContext } from 'react';
import axios from '../../services/api';
import { AuthContext } from '../../contexts/AuthContext';
import './Profile.css'; // Import the CSS file for styling

interface ProfileData {
  username: string;
  role: string;
  profilePicture: string;
}

const Profile: React.FC = () => {
  const [profile, setProfile] = useState<ProfileData>();
  const { user, isAuthenticated } = useContext(AuthContext);
  const [profilePicture, setProfilePicture] = useState<File | null>(null);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await axios.get('/api/users/profile');
        setProfile(response.data);
      } catch (error) {
        console.error('Error fetching profile:', error);
      }
    };

    if (isAuthenticated) {
      fetchProfile();
    }
  }, [isAuthenticated]);

  const handleProfilePictureChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0] || null;
    setProfilePicture(file);
  };

  const handleProfilePictureUpload = async () => {
    if (profilePicture) {
      try {
        const formData = new FormData();
        formData.append('profilePicture', profilePicture);

        await axios.post('/api/users/profile/picture', formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });

        // Refresh the profile data after successful upload
        const response = await axios.get('/api/users/profile');
        setProfile(response.data);
      } catch (error) {
        console.error('Error uploading profile picture:', error);
      }
    }
  };

  return (
    <div>
      <h2>Profile</h2>
      {profile ? (
        <div className="profile-container">
          <div className="profile-picture-container">
            {profile.profilePicture ? (
              <img
                src={profile.profilePicture}
                alt="Profile"
                className="profile-picture"
              />
            ) : (
              <div className="default-profile-picture">No Profile Picture</div>
            )}
            <input
              type="file"
              accept="image/*"
              onChange={handleProfilePictureChange}
            />
            <button onClick={handleProfilePictureUpload}>Upload Picture</button>
          </div>
          <div className="profile-details">
            <p>Username: {profile.username}</p>
            <p>Role: {profile.role}</p>
          </div>
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default Profile;