import React, { useState } from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import AdvancedSearchBar from '../../components/SearchBar/AdvancedSearchBar';
import AdvancedSearchFilters from './AdvancedSearchFilters';

interface AdvancedSearchFiltersProps {
  onSearch: (query: string) => void;
  onFilters: (filters: {
    tags: string[];
    minRating: number | null;
    status: string[] | [];
    sortOption: string;
  }) => void;
  onSort: (option: string) => void;
  filters: {
    tags: string[];
    minRating: number | null;
    status: string[] | [];
    sortOption: string;
  };
}

const AdvancedSearch: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState('relevance');
  const [filters, setFilters] = useState<{
    tags: string[];
    minRating: number | null;
    status: string[] | [];
    sortOption: string;
  }>({
    tags: [],
    minRating: null,
    status: [],
    sortOption: 'relevance',
  });

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    // Call your search function with the query and filters
  };

  const handleSort = (option: string) => {
    setSortOption(option);
    setFilters((prevFilters) => ({ ...prevFilters, sortOption: option }));
    // Apply the sorting logic
  };

  const handleFilters = (updatedFilters: {
    tags: string[];
    minRating: number | null;
    status: string[] | [];
    sortOption: string;
  }) => {
    setFilters(updatedFilters);
    // Apply the filtering logic
  };

  return (
    <Container fluid>
      <AdvancedSearchBar onSearch={handleSearch} />
      <Row>
        <Col md={3}>
          <AdvancedSearchFilters
            onSearch={handleSearch}
            onFilters={handleFilters}
            onSort={handleSort}
            filters={filters}
          />
        </Col>
        <Col md={9}>
          {/* Render the search results here */}
          {/* Pass the searchQuery, sortOption, and filters as props */}
        </Col>
      </Row>
    </Container>
  );
};

export default AdvancedSearch;