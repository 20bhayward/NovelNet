import React, { useState } from 'react';
import { Form, Button } from 'react-bootstrap';
import './AdvancedSearchFilters.css';

interface AdvancedSearchFiltersProps {
    onSearch: (query: string) => void;
    onFilters: (filters: {
      tags: string[];
      minRating: number | null;
      status: string[];
      sortOption: string;
    }) => void;
    onSort: (option: string) => void;
    filters: {
      tags: string[];
      minRating: number | null;
      status: string[];
      sortOption: string;
    };
  }
  
  const AdvancedSearchFilters: React.FC<AdvancedSearchFiltersProps> = ({
    onSearch,
    onFilters,
    onSort,
    filters,
  }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [tags, setTags] = useState<string[]>(filters.tags);
    const [minRating, setMinRating] = useState<number | null>(filters.minRating);
    const [statuses, setStatuses] = useState<string[]>(filters.status);
    const [sortOption, setSortOption] = useState<string>(filters.sortOption);
  
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleSearchSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSearch(searchTerm);
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const option = e.target.value;
    setSortOption(option);
    onSort(option);
    onFilters({ ...filters, sortOption: option });
  };

  const handleTagsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const tag = e.target.value;
    if (e.target.checked) {
      setTags([...tags, tag]);
    } else {
      setTags(tags.filter((t) => t !== tag));
    }
    onFilters({ ...filters, tags: [...tags, tag] });
  };

  const handleMinRatingChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value ? parseInt(e.target.value, 10) : null;
    setMinRating(value);
    onFilters({ ...filters, minRating: value });
  };

  const handleStatusChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const status = e.target.value;
    if (e.target.checked) {
      setStatuses([...statuses, status]);
    } else {
      setStatuses(statuses.filter((s) => s !== status));
    }
    onFilters({ ...filters, status: [...statuses, status] });
  };

  const genres = [
    'Action',
    'Adventure',
    'Comedy',
    'Drama',
    'Fantasy',
    'Horror',
    'Mahou Shoujo',
    'Mecha',
    'Music',
    'Mystery',
    'Psychological',
    'Romance',
    'Sci-Fi',
    'Slice of Life',
    'Sports',
    'Supernatural',
    'Thriller',
  ];

  return (
    <div className="advanced-search-filters">
      <Form onSubmit={handleSearchSubmit}>
        <Form.Group controlId="searchInput">
          <Form.Label>Search</Form.Label>
          <Form.Control
            type="text"
            value={searchTerm}
            onChange={handleSearchChange}
            placeholder="Enter search term"
          />
        </Form.Group>
        <Button variant="primary" type="submit">
          Search
        </Button>
      </Form>

      <Form.Group controlId="sortOptions">
        <Form.Label>Sort By</Form.Label>
        <Form.Control as="select" value={sortOption} onChange={handleSortChange}>
          <option value="relevance">Relevance</option>
          <option value="alphabetical">Alphabetical</option>
          <option value="rating">Rating</option>
          <option value="popularity">Popularity</option>
        </Form.Control>
      </Form.Group>

      <Form.Group controlId="tagsFilter">
        <Form.Label>Tags</Form.Label>
        {genres.map((genre) => (
          <Form.Check
            key={genre}
            type="checkbox"
            label={genre}
            value={genre.toLowerCase()}
            checked={tags.includes(genre.toLowerCase())}
            onChange={handleTagsChange}
          />
        ))}
      </Form.Group>

      <Form.Group controlId="ratingFilter">
        <Form.Label>Minimum Rating</Form.Label>
        <Form.Control
          type="number"
          value={minRating || ''}
          onChange={handleMinRatingChange}
          min={0}
          max={100}
        />
      </Form.Group>

      <Form.Group controlId="statusFilter">
        <Form.Label>Status</Form.Label>
        <Form.Check
          type="checkbox"
          label="Ongoing"
          value="ongoing"
          checked={statuses.includes('ongoing')}
          onChange={handleStatusChange}
        />
        <Form.Check
          type="checkbox"
          label="Completed"
          value="completed"
          checked={statuses.includes('completed')}
          onChange={handleStatusChange}
        />
      </Form.Group>
    </div>
  );
};

export default AdvancedSearchFilters;