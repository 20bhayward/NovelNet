import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Layout from './components/Layout/Layout';
import Home from './pages/Home/Home';
import Login from './pages/Login/Login';
import Register from './pages/Register/Register';
import Profile from './pages/Profile/Profile';
import NovelDetails from './pages/NovelDetails/NovelDetails';
import Search from './pages/Search/Search';
import AdvancedSearch from './pages/Search/AdvancedSearch';
import ProtectedRoute from './components/ProtectedRoute/ProtectedRoute';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/profile"
          element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          }
        />
        <Route path="/novel/:id" element={<NovelDetails />} />
        <Route path="/search" element={<Search />} />
        <Route path="/advanced-search" element={<AdvancedSearch />} />
      </Route>
    </Routes>
  );
}

export default App;